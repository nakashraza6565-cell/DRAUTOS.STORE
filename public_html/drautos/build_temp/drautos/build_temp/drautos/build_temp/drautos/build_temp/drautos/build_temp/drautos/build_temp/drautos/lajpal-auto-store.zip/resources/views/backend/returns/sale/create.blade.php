@extends('backend.layouts.master')

@section('title','Create Sale Return')

@section('main-content')
<div class="card">
    <h5 class="card-header">Create Sale Return / Refund (Order: {{$order->order_number}})</h5>
    <div class="card-body">
        <form action="{{route('returns.sale.store')}}" method="POST" id="returnForm">
            @csrf
            <input type="hidden" name="order_id" value="{{$order->id}}">
            <input type="hidden" name="customer_id" value="{{$order->user_id}}">

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Return Date</label>
                        <input type="date" name="return_date" class="form-control" value="{{date('Y-m-d')}}" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Refund Method</label>
                        <select name="refund_method" class="form-control" required>
                            <option value="cash">Cash</option>
                            <option value="credit_note">Credit Applied to Balance</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="cheque">Cheque</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Reference (Optional)</label>
                        <input type="text" name="refund_reference" class="form-control" placeholder="e.g. Transaction ID">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Reason</label>
                <textarea name="reason" class="form-control" rows="2"></textarea>
            </div>

            <hr>
            <h6 class="font-weight-bold">Select Items to Return</h6>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="bg-light">
                        <tr>
                            <th>Product</th>
                            <th>Sold Price</th>
                            <th>Qty Sold</th>
                            <th>Return Qty</th>
                            <th>Condition</th>
                            <th>Total Refund</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($order->cart as $index => $item)
                        <tr class="item-row">
                            <td>
                                {{$item->product->title}}
                                <input type="hidden" name="items[{{$index}}][product_id]" value="{{$item->product_id}}">
                                <input type="hidden" name="items[{{$index}}][unit_price]" value="{{$item->price}}">
                            </td>
                            <td>Rs. {{number_format($item->price, 2)}}</td>
                            <td>{{$item->quantity}}</td>
                            <td>
                                <input type="number" name="items[{{$index}}][quantity]" class="form-control return-qty" 
                                       min="0" max="{{$item->quantity}}" value="0" data-price="{{$item->price}}">
                            </td>
                            <td>
                                <select name="items[{{$index}}][condition]" class="form-control">
                                    <option value="good">Good (Restock)</option>
                                    <option value="damaged">Damaged</option>
                                    <option value="defective">Defective</option>
                                </select>
                            </td>
                            <td class="text-right font-weight-bold row-total">
                                Rs. 0.00
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="5" class="text-right">Total Refund Amount:</th>
                            <th class="text-right display-total" style="font-size: 1.2em;">Rs. 0.00</th>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="text-right mt-3">
                <button type="submit" class="btn btn-primary btn-lg">Process Refund</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function() {
        $('.return-qty').on('input change', function() {
            let qty = parseInt($(this).val()) || 0;
            let max = parseInt($(this).attr('max'));
            let price = parseFloat($(this).data('price'));
            
            if(qty < 0) qty = 0;
            if(qty > max) {
                alert('Cannot return more than sold quantity ('+max+')');
                $(this).val(max);
                qty = max;
            }

            let total = qty * price;
            $(this).closest('tr').find('.row-total').text('Rs. ' + total.toFixed(2));

            calculateGrandTotal();
        });

        function calculateGrandTotal() {
            let grandTotal = 0;
            $('.return-qty').each(function() {
                let qty = parseInt($(this).val()) || 0;
                let price = parseFloat($(this).data('price'));
                grandTotal += qty * price;
            });
            $('.display-total').text('Rs. ' + grandTotal.toFixed(2));
        }

        $('#returnForm').on('submit', function(e) {
            let grandTotal = 0;
            $('.return-qty').each(function() {
                grandTotal += parseInt($(this).val()) || 0;
            });

            if(grandTotal === 0) {
                e.preventDefault();
                alert('Please select at least one item to return.');
            }
        });
    });
</script>
@endpush
