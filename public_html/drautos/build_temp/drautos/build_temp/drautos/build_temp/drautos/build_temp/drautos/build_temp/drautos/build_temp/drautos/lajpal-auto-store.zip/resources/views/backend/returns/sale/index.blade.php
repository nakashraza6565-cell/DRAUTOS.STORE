@extends('backend.layouts.master')

@section('main-content')
<div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">Sale Returns</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        @if(count($returns ?? [])>0)
        <table class="table table-bordered" id="data-table">
          <thead>
            <tr>
              <th>Return #</th>
              <th>Date</th>
              <th>Order #</th>
              <th>Type</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @foreach($returns as $return)   
                <tr>
                    <td><strong>{{$return->return_number}}</strong></td>
                    <td>{{$return->return_date->format('d M Y')}}</td>
                    <td>{{$return->order->order_number ?? 'N/A'}}</td>
                    <td>
                        @if(($return->type ?? 'return') == 'claim')
                            <span class="badge badge-warning">Claim</span>
                        @else
                            <span class="badge badge-info">Return</span>
                        @endif
                    </td>
                    <td>{{$return->customer->name ?? 'N/A'}}</td>
                    <td>{{$return->items->count()}} items</td>
                    <td>PKR {{number_format($return->total_return_amount, 2)}}</td>
                    <td>
                        @if($return->status == 'pending')
                            <span class="badge badge-warning">Pending</span>
                        @elseif($return->status == 'approved')
                            <span class="badge badge-success">Approved</span>
                        @elseif($return->status == 'rejected')
                            <span class="badge badge-danger">Rejected</span>
                        @else
                            <span class="badge badge-info">Completed</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{route('returns.sale.show', $return->id)}}" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a>
                        @if($return->status == 'pending')
                        <form method="POST" action="{{route('returns.sale.approve',$return->id)}}" style="display:inline;">
                          @csrf
                          <button class="btn btn-success btn-sm" title="Approve"><i class="fas fa-check"></i></button>
                        </form>
                        @endif
                    </td>
                </tr>  
            @endforeach
          </tbody>
        </table>
        @else
          <h6 class="text-center">No Sale Returns Found!</h6>
        @endif
      </div>
    </div>
</div>
@endsection
