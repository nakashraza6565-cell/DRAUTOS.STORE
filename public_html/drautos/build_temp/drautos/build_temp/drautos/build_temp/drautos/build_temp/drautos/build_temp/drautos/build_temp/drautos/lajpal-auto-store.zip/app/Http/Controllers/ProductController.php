<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Brand;

use Illuminate\Support\Str;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::getAllProduct();
        return view('backend.product.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $brands = Brand::get();
        $categories = Category::where('is_parent', 1)->get();
        $suppliers = \App\Models\Supplier::where('status', 'active')->get();
        $warehouses = \App\Models\Warehouse::where('status', 'active')->get();
        $units = \App\Models\Unit::all();
        return view('backend.product.create', compact('categories', 'brands', 'suppliers', 'warehouses', 'units'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'title'               => 'required|string|max:255',
            'summary'             => 'nullable|string',
            'description'         => 'nullable|string',
            'photo'               => 'nullable|string',
            'size'                => 'nullable|array',
            'size.*'              => 'nullable|string',
            'stock'               => 'required|numeric|min:0',
            'cat_id'              => 'required|exists:categories,id',
            'brand_id'            => 'nullable|exists:brands,id',
            'child_cat_id'        => 'nullable|exists:categories,id',
            'is_featured'         => 'sometimes|in:1',
            'status'              => 'nullable|in:active,inactive',
            'condition'           => 'nullable|in:default,new,hot',
            'price'               => 'required|numeric|min:0',
            'purchase_price'      => 'nullable|numeric|min:0',
            'packaging_cost'      => 'nullable|numeric|min:0',
            'discount'            => 'nullable|numeric|min:0|max:100',
            'sku'                 => 'nullable|string|max:100|unique:products,sku',
            'barcode'             => 'nullable|string|max:255',
            'low_stock_threshold' => 'required|numeric|min:0',
            'suppliers'           => 'required|array',
            'suppliers.*'         => 'exists:suppliers,id',
            'warehouse_id'        => 'nullable|exists:warehouses,id',
            'weight'              => 'nullable|numeric|min:0',
            'batch_number'        => 'nullable|string|max:255',
            'wholesale_price'     => 'nullable|numeric|min:0',
            'retail_price'        => 'nullable|numeric|min:0',
            'walkin_price'        => 'nullable|numeric|min:0',
            'salesman_price'      => 'nullable|numeric|min:0',
            'rack_number'         => 'nullable|string|max:255',
            'shelf_number'        => 'nullable|string|max:255',
            'color'               => 'nullable|string|max:255',
            'type'                => 'nullable|string|max:255',
            'unit'                => 'nullable|string|max:255',
        ]);

        $validatedData['status'] = $request->input('status') ?? 'active';
        $validatedData['condition'] = $request->input('condition') ?? 'default';
        $validatedData['summary'] = $request->input('summary') ?? '';
        $validatedData['photo'] = $request->input('photo') ?? '';
        $validatedData['purchase_price'] = $request->input('purchase_price') ?? 0;
        $validatedData['packaging_cost'] = $request->input('packaging_cost') ?? 0;
        $validatedData['discount'] = $request->input('discount') ?? 0;
        $validatedData['unit_type'] = $request->input('unit_type') ?? 'piece';

        $slug = Str::slug($request->title);
        $count = Product::where('slug', $slug)->count();
        if($count > 0){
            $slug = $slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $validatedData['slug'] = $slug;
        $validatedData['is_featured'] = $request->input('is_featured', 0);

        if ($request->has('size')) {
            $validatedData['size'] = is_array($request->input('size')) ? implode(',', $request->input('size')) : $request->input('size');
        } else {
            $validatedData['size'] = '';
        }

        $product = Product::create($validatedData);
        if($request->suppliers){
            $product->suppliers()->sync($request->suppliers);
        }

        return redirect()->route('product.index')->with('success', 'Product Successfully added');
    }

    public function edit($id)
    {
        $brands = Brand::get();
        $product = Product::with('suppliers')->findOrFail($id);
        $categories = Category::where('is_parent', 1)->get();
        $suppliers = \App\Models\Supplier::where('status', 'active')->get();
        $warehouses = \App\Models\Warehouse::where('status', 'active')->get();
        $units = \App\Models\Unit::all();

        return view('backend.product.edit', compact('product', 'brands', 'categories', 'suppliers', 'warehouses', 'units'));
    }

    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $validatedData = $request->validate([
            'title'               => 'required|string|max:255',
            'summary'             => 'nullable|string',
            'description'         => 'nullable|string',
            'photo'               => 'nullable|string',
            'size'                => 'nullable|array',
            'size.*'              => 'nullable|string',
            'stock'               => 'required|numeric|min:0',
            'cat_id'              => 'required|exists:categories,id',
            'child_cat_id'        => 'nullable|exists:categories,id',
            'is_featured'         => 'sometimes|in:1',
            'brand_id'            => 'nullable|exists:brands,id',
            'status'              => 'nullable|in:active,inactive',
            'condition'           => 'nullable|in:default,new,hot',
            'price'               => 'required|numeric|min:0',
            'purchase_price'      => 'nullable|numeric|min:0',
            'packaging_cost'      => 'nullable|numeric|min:0',
            'discount'            => 'nullable|numeric|min:0|max:100',
            'sku'                 => 'nullable|string|max:100|unique:products,sku,'.$id,
            'barcode'             => 'nullable|string|max:255',
            'low_stock_threshold' => 'required|numeric|min:0',
            'suppliers'           => 'required|array',
            'suppliers.*'         => 'exists:suppliers,id',
            'warehouse_id'        => 'nullable|exists:warehouses,id',
            'weight'              => 'nullable|numeric|min:0',
            'batch_number'        => 'nullable|string|max:255',
            'wholesale_price'     => 'nullable|numeric|min:0',
            'retail_price'        => 'nullable|numeric|min:0',
            'walkin_price'        => 'nullable|numeric|min:0',
            'salesman_price'      => 'nullable|numeric|min:0',
            'rack_number'         => 'nullable|string|max:255',
            'shelf_number'        => 'nullable|string|max:255',
            'color'               => 'nullable|string|max:255',
            'type'                => 'nullable|string|max:255',
            'unit'                => 'nullable|string|max:255',
        ]);

        $validatedData['status'] = $request->input('status') ?? $product->status;
        $validatedData['condition'] = $request->input('condition') ?? $product->condition;
        $validatedData['summary'] = $request->input('summary') ?? $product->summary ?? '';
        $validatedData['photo'] = $request->input('photo') ?? $product->photo ?? '';
        $validatedData['purchase_price'] = $request->input('purchase_price') ?? $product->purchase_price ?? 0;
        $validatedData['packaging_cost'] = $request->input('packaging_cost') ?? $product->packaging_cost ?? 0;
        $validatedData['discount'] = $request->input('discount') ?? $product->discount ?? 0;
        $validatedData['unit_type'] = $request->input('unit_type') ?? $product->unit_type ?? 'piece';
        $validatedData['unit'] = $request->input('unit') ?? $product->unit ?? null;

        $validatedData['is_featured'] = $request->input('is_featured', 0);

        if ($request->has('size')) {
            $validatedData['size'] = is_array($request->input('size')) ? implode(',', $request->input('size')) : $request->input('size');
        } else {
            $validatedData['size'] = '';
        }

        $status = $product->update($validatedData);
        if($request->has('suppliers')){
             $product->suppliers()->sync($request->suppliers);
        }

        return redirect()->route('product.index')->with('success', 'Product Successfully updated');
    }

    public function lowStock()
    {
        // Treat null threshold as 0
        $products = Product::with(['cat_info', 'sub_cat_info', 'brand', 'supplier'])
            ->whereRaw('stock <= COALESCE(low_stock_threshold, 0)')
            ->orderBy('stock', 'ASC')
            ->paginate(5000);
        return view('backend.product.index', compact('products'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $status = $product->delete();

        $message = $status
            ? 'Product successfully deleted'
            : 'Error while deleting product';

        return redirect()->route('product.index')->with(
            $status ? 'success' : 'error',
            $message
        );
    }

    public function storeUnit(Request $request)
    {
        try {
            $request->validate(['name' => 'required|string|max:255']);
            $unit = \App\Models\Unit::create(['name' => $request->name]);
            return response()->json(['status' => 'success', 'unit' => $unit]);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 422);
        }
    }
}
