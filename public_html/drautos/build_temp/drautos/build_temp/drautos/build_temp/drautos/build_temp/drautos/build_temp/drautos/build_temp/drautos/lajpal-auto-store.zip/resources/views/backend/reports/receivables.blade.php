@extends('backend.layouts.master')

@section('main-content')
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Account Receivables Report</h1>
        <button class="btn btn-sm btn-primary shadow-sm" onclick="window.print()"><i class="fas fa-print fa-sm text-white-50"></i> Print Report</button>
    </div>

    <!-- Summary -->
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Outstanding Receivables</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Rs. {{number_format($totalReceivable, 2)}}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-arrow-down fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Pending Payments from Customers</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="receivablesTable">
                            <thead class="bg-light text-dark">
                                <tr>
                                    <th>Customer</th>
                                    <th>Ref #</th>
                                    <th>Due Date</th>
                                    <th>Pending Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($receivables as $receivable)
                                <tr>
                                    <td>{{$receivable->party->name ?? 'N/A'}}</td>
                                    <td>{{$receivable->reference_number}}</td>
                                    <td class="{{\Carbon\Carbon::parse($receivable->due_date)->isPast() ? 'text-danger font-weight-bold' : ''}}">
                                        {{$receivable->due_date->format('d M Y')}}
                                    </td>
                                    <td class="font-weight-bold text-success">Rs. {{number_format($receivable->amount, 2)}}</td>
                                    <td>
                                        <span class="badge badge-info">{{strtoupper($receivable->status)}}</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="card shadow mb-4 text-center">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Customer Receivable Split</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2" style="height: 300px;">
                        <canvas id="receivablePieChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script>
    var ctx = document.getElementById("receivablePieChart");
    var myPieChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: {!! json_encode($byCustomer->map(fn($c) => $c->party->name ?? 'Unknown')) !!},
            datasets: [{
                data: {!! json_encode($byCustomer->pluck('total')) !!},
                backgroundColor: ['#1cc88a', '#36b9cc', '#4e73df', '#f6c23e', '#e74a3b', '#858796'],
            }],
        },
        options: {
            maintainAspectRatio: false,
            legend: { position: 'bottom' }
        },
    });
</script>
@endpush
