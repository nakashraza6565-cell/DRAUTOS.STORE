<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerLedger;
use App\User;
use Illuminate\Support\Facades\DB;

class CustomerLedgerController extends Controller
{
    public function index(Request $request)
    {
        $query = User::whereIn('role', ['user', 'customer']);
        
        if ($request->search) {
            $query->where(function($q) use ($request) {
                $q->where('name', 'LIKE', '%' . $request->search . '%')
                  ->orWhere('phone', 'LIKE', '%' . $request->search . '%')
                  ->orWhere('email', 'LIKE', '%' . $request->search . '%');
            });
        }

        $customers = $query->orderBy('name', 'asc')->paginate(5000);
        return view('backend.customer_ledger.index', compact('customers'));
    }

    public function show(User $user, Request $request)
    {
        $query = CustomerLedger::where('user_id', $user->id);

        if ($request->date_from) {
            $query->whereDate('transaction_date', '>=', $request->date_from);
        }
        if ($request->date_to) {
            $query->whereDate('transaction_date', '<=', $request->date_to);
        }

        $ledger = $query->orderBy('transaction_date', 'asc')->get();
        
        // Prepare Graph Data (Professional Performance)
        $graphLabels = [];
        $balanceHistory = [];
        $runningBalance = 0;
        
        foreach ($ledger as $item) {
            $graphLabels[] = date('d M', strtotime($item->transaction_date));
            if ($item->type == 'debit') {
                $runningBalance += $item->amount;
            } else {
                $runningBalance -= $item->amount;
            }
            $balanceHistory[] = $runningBalance;
        }

        $ledger = $query->orderBy('transaction_date', 'desc')->orderBy('id', 'desc')->paginate(5000);
        // The original method signature includes `User $user`, so we should use that.
        // If this method is intended for the authenticated user, the signature should be changed.
        // For now, we keep the passed $user object.
        
        return view('backend.customer_ledger.show', compact('user', 'ledger', 'graphLabels', 'balanceHistory'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'transaction_date' => 'required|date',
            'type' => 'required|in:credit,debit',
            'amount' => 'required|numeric|min:0',
            'description' => 'required|string',
            'category' => 'required|in:manual,payment,order,return'
        ]);

        try {
            CustomerLedger::record(
                $validated['user_id'],
                $validated['transaction_date'],
                $validated['type'],
                $validated['category'],
                $validated['description'],
                $validated['amount']
            );

            return redirect()->back()->with('success', 'Transaction recorded successfully');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Error: ' . $e->getMessage());
        }
    }
}
