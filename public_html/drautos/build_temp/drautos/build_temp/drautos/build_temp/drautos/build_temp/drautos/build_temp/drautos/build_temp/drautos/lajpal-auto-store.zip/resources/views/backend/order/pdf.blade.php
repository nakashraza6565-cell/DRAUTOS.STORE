<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Invoice {{ $order->order_number ?? '' }} | Danyal Autos</title>
    <style>
        /* Modern & Professional Invoice Design - Danyal Autos */
        @page { margin: 10mm; size: a4; }
        
        body {
            font-family: 'DejaVu Sans', sans-serif; /* Changed back to DejaVu Sans for Urdu support */
            margin: 0;
            padding: 0;
            color: #2D3748;
            line-height: 1.4;
            background: #fff;
            font-size: 11px;
        }
        
        .chocolate-theme { color: #4b312c; }
        .bg-chocolate { background-color: #4b312c; }
        
        .header {
            padding-bottom: 20px;
            border-bottom: 2px solid #e2e8f0;
            margin-bottom: 20px;
            position: relative;
        }
        
        .company-info {
            float: left;
            width: 50%;
        }
        
        .company-name {
            font-size: 28px;
            font-weight: bold;
            color: #4b312c;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        
        .company-details {
            font-size: 10px;
            color: #718096;
        }
        
        .invoice-title-wrapper {
            float: right;
            width: 45%;
            text-align: right;
        }
        
        .invoice-label {
            font-size: 40px;
            font-weight: bold;
            color: #4b312c;
            margin: 0;
            line-height: 1;
        }
        
        .invoice-no-main {
            font-size: 12px;
            color: #718096;
            margin-top: 5px;
            font-weight: bold;
        }
        
        /* Summary Row */
        .summary-row {
            margin-top: 20px;
            margin-bottom: 30px;
            border-bottom: 1px solid #edf2f7;
            padding-bottom: 15px;
        }
        
        .summary-item {
            float: left;
            width: 33.33%;
        }
        
        .summary-label {
            font-size: 10px;
            font-weight: bold;
            color: #718096;
            text-transform: uppercase;
            margin-bottom: 3px;
        }
        
        .summary-value {
            font-size: 16px;
            font-weight: bold;
            color: #4b312c;
        }
        
        /* Billing & Shipping */
        .info-grid {
            margin-bottom: 30px;
        }
        
        .info-box {
            float: left;
            width: 55%;
        }
        
        .shipping-box {
            float: right;
            width: 40%;
            background: #fdfaf9;
            border: 1px solid #f2e9e7;
            padding: 12px;
            border-radius: 6px;
        }
        
        .box-title {
            font-size: 12px;
            font-weight: bold;
            color: #4b312c;
            margin-bottom: 8px;
            text-transform: uppercase;
            border-bottom: 1px solid #f2e9e7;
            padding-bottom: 3px;
        }
        
        .info-text {
            font-size: 11px;
            line-height: 1.5;
        }
        
        .info-text strong {
            font-size: 13px;
            display: block;
            margin-bottom: 2px;
            color: #2D3748;
        }
        
        /* Table Style */
        .item-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        
        .item-table th {
            background-color: #4b312c;
            color: white;
            padding: 10px 8px;
            font-size: 10px;
            text-transform: uppercase;
            font-weight: bold;
            text-align: left;
        }
        
        .item-table td {
            padding: 10px 8px;
            font-size: 11px;
            border-bottom: 1px solid #edf2f7;
        }
        
        .item-row:nth-child(even) { background-color: #fbf9f8; }
        
        /* Totals section with table to prevent overlapping */
        .totals-section {
            margin-top: 20px;
        }
        
        .payment-notes {
            float: left;
            width: 45%;
            background: #f7fafc;
            padding: 12px;
            border-radius: 6px;
            font-size: 10px;
        }
        
        .totals-table-wrapper {
            float: right;
            width: 45%;
        }
        
        .totals-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .totals-table td {
            padding: 4px 0;
            font-size: 12px;
        }
        
        .totals-table .label {
            text-align: left;
            color: #718096;
        }
        
        .totals-table .value {
            text-align: right;
            font-weight: bold;
            color: #2D3748;
        }
        
        .grand-total-highlight {
            background-color: #4b312c;
            color: white !important;
        }
        
        .grand-total-highlight td {
            padding: 8px 10px;
            font-size: 15px;
            font-weight: bold;
        }
        
        .grand-total-highlight .label { color: #fff; }
        .grand-total-highlight .value { color: #fff; }
        
        /* Footer */
        .urdu-section {
            margin-top: 50px;
            text-align: center;
            border-top: 1px solid #e2e8f0;
            padding-top: 20px;
            /* dompdf needs special handling for RTL, usually span with dir */
        }
        
        .urdu-text {
            font-size: 18px;
            font-weight: bold;
            color: #4b312c;
            margin-bottom: 5px;
            direction: rtl;
            display: block;
            line-height: 1.6;
        }
        
        .final-footer {
            margin-top: 20px;
            text-align: center;
            font-size: 9px;
            color: #a0aec0;
        }
        
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }
        
        .courier-info {
            margin-top: 8px;
            font-size: 10px;
            color: #4a5568;
            padding: 5px;
            border: 1px dashed #cbd5e0;
            border-radius: 4px;
        }

        @font-face {
            font-family: 'Revue';
            src: url("{{ str_replace('\\', '/', public_path('revue/reve.ttf')) }}") format("truetype");
            font-weight: normal;
            font-style: normal;
        }

        /* Background Watermark */
        .watermark {
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%); /* Straight position, no rotation */
            font-size: 400px;
            color: #4b312c;
            opacity: 0.15;
            z-index: -1000;
            font-family: 'Revue', sans-serif;
            text-transform: uppercase;
            pointer-events: none;
            white-space: nowrap;
        }
    </style>
</head>
<body>
    <div class="watermark">DR</div>
    <div class="header clearfix">
        <div class="company-info">
            <div class="company-name">Danyal Autos</div>
            <div class="company-details">
                12-BUTT MARKET BADAMI BAGH LAHORE<br>
                Zip Code: 54000 <br>
                Contact No: +923042000274 | 04237727045
            </div>
        </div>
        <div class="invoice-title-wrapper">
            <h1 class="invoice-label">INVOICE</h1>
            <div class="invoice-no-main">#{{ $order->order_number }}</div>
            <div style="margin-top: 10px; font-size: 24px; font-weight: bold; color: #4b312c;">
                Rs. {{ number_format($order->total_amount, 2) }}
            </div>
        </div>
    </div>

    <div class="summary-row clearfix">
        <div class="summary-item">
            <div class="summary-label">Account Balance</div>
            <div class="summary-value">Rs. {{ number_format($order->user->current_balance ?? $order->total_amount, 2) }}</div>
        </div>
        <div class="summary-item" style="text-align: center;">
            <div class="summary-label">Invoice Date</div>
            <div class="summary-value">{{ $order->created_at->format('d M, Y') }}</div>
        </div>
        <div class="summary-item" style="text-align: right;">
            <div class="summary-label">Due Date</div>
            <div class="summary-value">{{ now()->addDays(7)->format('d M, Y') }}</div>
        </div>
    </div>

    <div class="info-grid clearfix">
        <div class="info-box">
            <div class="box-title">Invoice To:</div>
            <div class="info-text">
                <strong>{{ strtoupper($order->first_name) }} {{ strtoupper($order->last_name) }}</strong>
                Address: {{ $order->address1 }}<br>
                Phone: {{ $order->phone }}<br>
                Email: {{ $order->email }}
            </div>
        </div>
        <div class="shipping-box">
            <div class="box-title">Shipping & Logistics:</div>
            <div class="info-text">
                Type: {{ strtoupper($order->order_type ?? 'courier') }}<br>
                @if($order->courier_company)
                    <div class="courier-info">
                        <strong>courier company:{{ strtoupper($order->courier_company) }}</strong><br>
                        Tracking: {{ $order->courier_number }}
                    </div>
                @else
                    Ship To: {{ $order->country ?? 'Pakistan' }}
                @endif
            </div>
        </div>
    </div>

    <table class="item-table">
        <thead>
            <tr>
                <th width="8%">NO.</th>
                <th width="35%">PRODUCT DESCRIPTION</th>
                <th width="10%" style="text-align: center;">QTY</th>
                <th width="15%" style="text-align: right;">PRICE (ACTUAL)</th>
                <th width="15%" style="text-align: right;">PRICE (DISC.)</th>
                <th width="20%" style="text-align: right;">TOTAL</th>
            </tr>
        </thead>
        <tbody>
            @foreach($order->cart_info as $index => $cart)
            <tr class="item-row">
                <td>{{ str_pad($index + 1, 2, '0', STR_PAD_LEFT) }}</td>
                <td>
                    <div style="font-weight: bold; color: #4b312c;">{{ $cart->product->title ?? ($cart->bundle->name ?? 'Item') }}</div>
                    @if($cart->product && $cart->product->sku)
                        <div style="font-size: 8px; color: #a0aec0;">SKU: {{ $cart->product->sku }}</div>
                    @endif
                    @if($cart->product && $cart->product->brand)
                        <div style="font-size: 8px; color: #4b312c; font-weight: 500;">Brand: {{ $cart->product->brand->title }}</div>
                    @endif
                </td>
                <td style="text-align: center;">
                    {{ $cart->quantity }}
                    @if($cart->product && $cart->product->unit)
                        <div style="font-size: 8px; color: #4b312c;">{{ $cart->product->unit }}</div>
                    @endif
                </td>
                <td style="text-align: right;">
                    <del style="color: #a0aec0; font-size: 9px;">{{ number_format($cart->product->price ?? $cart->price, 2) }}</del>
                </td>
                <td style="text-align: right;">
                    {{ number_format($cart->price, 2) }}
                    <div style="font-size: 8px; color: #4b312c; margin-top: 2px;">(Discounted)</div>
                </td>
                <td style="text-align: right; font-weight: bold;">{{ number_format($cart->amount, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="totals-section clearfix">
        <div class="payment-notes">
            <div class="box-title" style="font-size: 10px;">Payment Information</div>
            Bank Name: Meezan bank<br>
            Beneficiary: Sheikh Imtiaz ali tahir<br>
            A/C: 0256 0103847320<br>
            <div style="margin-top: 8px; font-style: italic;">
                Status: {{ strtoupper($order->payment_status) }}
            </div>
        </div>
        <div class="totals-table-wrapper">
            <table class="totals-table">
                <tr>
                    <td class="label">SUB TOTAL</td>
                    <td class="value">Rs. {{ number_format($order->sub_total, 2) }}</td>
                </tr>
                @if($order->coupon > 0)
                <tr>
                    <td class="label">TOTAL DISCOUNT</td>
                    <td class="value" style="color: #38a169;">- Rs. {{ number_format($order->coupon, 2) }}</td>
                </tr>
                @endif
                @php 
                    $item_discount = 0;
                    foreach($order->cart_info as $ci) {
                        $actual = $ci->product->price ?? $ci->price;
                        if($actual > $ci->price) {
                            $item_discount += ($actual - $ci->price) * $ci->quantity;
                        }
                    }
                @endphp
                @if($item_discount > 0)
                <tr>
                    <td class="label">ITEM DISCOUNTS</td>
                    <td class="value" style="color: #38a169;">- Rs. {{ number_format($item_discount, 2) }}</td>
                </tr>
                @endif
                @if($order->shipping && $order->shipping->price > 0)
                <tr>
                    <td class="label">SHIPPING</td>
                    <td class="value">Rs. {{ number_format($order->shipping->price, 2) }}</td>
                </tr>
                @endif
                <tr class="grand-total-highlight">
                    <td class="label">GRAND TOTAL</td>
                    <td class="value">Rs. {{ number_format($order->total_amount, 2) }}</td>
                </tr>
                <tr>
                    <td class="label" style="padding-top: 10px;">Amount Paid</td>
                    @php
                        $requested_pending = 0;
                        $reminder = \App\Models\PaymentReminder::where('reference_number', $order->order_number)->first();
                        if ($reminder) {
                            $requested_pending = $reminder->amount - $reminder->paid_amount;
                        }
                    @endphp
                    <td class="value" style="padding-top: 10px;">Rs. {{ number_format($order->total_amount - $requested_pending, 2) }}</td>
                </tr>
                <tr>
                    <td class="label">Balance Due</td>
                    <td class="value" style="color: #c53030;">Rs. {{ number_format($requested_pending, 2) }}</td>
                </tr>
            </table>
        </div>
    </div>

    <!-- <div class="urdu-section">
        <div class="urdu-text">
            {{ Helper::reshapeUrdu("سیلزمین یا سپلائی میں کے ساتھ ذاتي لين دين کي کمپني ذمہ دار نا ہو گي بغير بل کے کسي بهي سیلزمین کو وصولي نا دیں اور مال لیتے وقت تسلی کر لیں") }}
        </div>
        <div class="urdu-text" style="font-size: 14px; opacity: 0.8;">
            {{ Helper::reshapeUrdu("ہم نے حلال میں ہی برکت رکھی ہے - جو وعدہ پورا کرے، وہی کامیاب ہے") }}
        </div>
    </div> -->

    <div class="final-footer">
        <strong>THANK YOU FOR YOUR BUSINESS!</strong><br>
        This is a computer generated document. | Danyal Autos &copy; {{ date('Y') }}
        <br>This software is designed and developed by (Expert Code Sol) Email: irfanwaince555@gmail.com
    </div>
</body>
</html>
