@extends('backend.layouts.master')

@section('main-content')
 <!-- DataTales Example -->
 <div class="card shadow mb-4">
     <div class="row">
         <div class="col-md-12">
            @include('backend.layouts.notification')
         </div>
     </div>
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">Order Lists</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        @if(count($orders)>0)
        <table class="table table-bordered" id="order-dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Order No.</th>
              <th>Cust #</th>
              <th>Customer Name</th>
              <th>Assigned Staff</th>
              <th>Rating Pnts</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>Order No.</th>
              <th>Cust #</th>
              <th>Customer Name</th>
              <th>Assigned Staff</th>
              <th>Rating Pnts</th>
              <th>Status</th>
              <th>Action</th>
              </tr>
          </tfoot>
          <tbody>
            @foreach($orders as $order)  
                <tr>
                    <td>{{$order->order_number}}</td>
                    <td>
                        @if($order->user_id)
                            <span class="badge badge-light">#{{$order->user_id}}</span>
                        @else
                            <span class="text-muted">N/A</span>
                        @endif
                    </td>
                    <td>
                        <div>{{$order->first_name}} {{$order->last_name}}</div>
                        <small class="text-muted">{{$order->phone}}</small>
                    </td>
                    <td>
                        @if($order->staff)
                            <span class="badge badge-success">{{$order->staff->name}}</span>
                        @else
                            <span class="badge badge-secondary">Unassigned</span>
                        @endif
                    </td>
                    <td>
                        @php
                            $user = $order->user;
                            $pnts = 0;
                            if($user) {
                                // Calculate total points from 4 categories (max 20)
                                $pnts = ($user->loyalty_rating ?? 0) + 
                                       ($user->goodwill_rating ?? 0) + 
                                       ($user->payment_rating ?? 0) + 
                                       ($user->behaviour_rating ?? 0);
                            }
                        @endphp
                        <div class="d-flex align-items-center">
                            <span class="text-warning mr-2"><i class="fas fa-star"></i></span>
                            <span class="font-weight-bold">{{$pnts}} / 20</span>
                        </div>
                    </td>
                    <td>
                        @if($order->status=='new')
                          <span class="badge badge-primary">{{$order->status}}</span>
                        @elseif($order->status=='process')
                          <span class="badge badge-warning">{{$order->status}}</span>
                        @elseif($order->status=='delivered')
                          <span class="badge badge-success">{{$order->status}}</span>
                        @else
                          <span class="badge badge-danger">{{$order->status}}</span>
                        @endif
                    </td>
                    <td>
                        <form method="POST" action="{{route('order.toggle-pin', $order->id)}}" style="display:inline-block">
                            @csrf
                            <button type="submit" class="btn btn-{{$order->pinned ? 'info' : 'outline-secondary'}} btn-sm float-left mr-1" style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" title="{{$order->pinned ? 'Unpin' : 'Pin to top'}}" data-placement="bottom">
                                <i class="fas fa-thumbtack"></i>
                            </button>
                        </form>
                        <a href="{{route('order.show',$order->id)}}" class="btn btn-warning btn-sm float-left mr-1" style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" title="view" data-placement="bottom"><i class="fas fa-eye"></i></a>
                        <a href="{{route('returns.sale.create',$order->id)}}" class="btn btn-dark btn-sm float-left mr-1" style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" title="Refund" data-placement="bottom"><i class="fas fa-undo"></i></a>
                        @if($order->status == 'delivered')
                            <button class="btn btn-secondary btn-sm float-left mr-1" style="height:30px; width:30px;border-radius:50%;opacity:0.5;cursor:not-allowed" disabled data-toggle="tooltip" title="Cannot edit delivered order" data-placement="bottom"><i class="fas fa-edit"></i></button>
                        @else
                            <a href="{{route('order.edit',$order->id)}}" class="btn btn-primary btn-sm float-left mr-1" style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" title="edit" data-placement="bottom"><i class="fas fa-edit"></i></a>
                        @endif
                        <form method="POST" action="{{route('order.destroy',[$order->id])}}">
                          @csrf 
                          @method('delete')
                              <button class="btn btn-danger btn-sm dltBtn" data-id={{$order->id}} style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" data-placement="bottom" title="Delete"><i class="fas fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>  
            @endforeach
          </tbody>
        </table>
        <span style="float:right">{{$orders->links()}}</span>
        @else
          <h6 class="text-center">No orders found!!! Please order some products</h6>
        @endif
      </div>
    </div>
    </div>
</div>

    </div>
</div>
@endsection

@push('styles')
  <link href="{{asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
  <style>
      
  </style>
@endpush

@push('scripts')

  <!-- Page level plugins -->
  <script src="{{asset('backend/vendor/datatables/jquery.dataTables.min.js')}}"></script>
  <script src="{{asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="{{asset('backend/js/demo/datatables-demo.js')}}"></script>
  <script>
      
      $('#order-dataTable').DataTable( {
            "order": [],
            "columnDefs":[
                {
                    "orderable":false,
                    "targets":[6]
                }
            ]
        } );

        // Sweet alert

        function deleteData(id){
            
        }
  </script>
  <script>
      $(document).ready(function(){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
          $('.dltBtn').click(function(e){
            var form=$(this).closest('form');
              var dataID=$(this).data('id');
              // alert(dataID);
              e.preventDefault();
              swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                       form.submit();
                    } else {
                        swal("Your data is safe!");
                    }
                });
          })
      })


  </script>
@endpush
