@extends('backend.layouts.master')
@section('title','Danyal Autos || DASHBOARD')
@section('main-content')
<div class="container-fluid" style="background: #f8fafc; min-height: 100vh; padding: 1.5rem;">
    @include('backend.layouts.notification')
    
    <!-- Dashboard Header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4 mt-2">
        <div class="d-flex align-items-center">
            <div style="background: #1e293b; width: 4px; height: 24px; border-radius: 2px; margin-right: 12px;"></div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold" style="font-size: 1.4rem;">Dashboard <span class="text-gray-400 font-weight-normal ml-2" style="font-size: 0.9rem;">Overview</span></h1>
        </div>
        <div class="d-flex align-items-center bg-white shadow-sm p-2 rounded-lg" style="border: 1px solid rgba(0,0,0,0.05); border-radius: 12px !important;">
            <div class="mr-3 text-gray-500 small">
                <i class="far fa-calendar-alt mr-1"></i> {{ date('D, M d, Y') }}
            </div>
            <div id="live-clock" class="font-weight-bold" style="min-width: 100px; text-align: right; color: #3b82f6;">
                <i class="far fa-clock mr-1"></i> {{ date('h:i:s A') }}
            </div>
        </div>
    </div>

    <!-- Stats Row 1: Key Metrics -->
    <div class="row mb-4">

      <!-- Category Card -->
      <div class="col-xl-2 col-md-6 mb-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; border-left: 4px solid #3b82f6 !important;">
          <div class="card-body p-4">
            <div class="d-flex align-items-center justify-content-between">
              <div>
                <div class="text-xs font-weight-bold text-gray-400 text-uppercase mb-1" style="letter-spacing: 0.05em;">CATEGORIES</div>
                <div class="h3 mb-0 font-weight-bold text-gray-800">{{ $category_count }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Products Card -->
      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; border-left: 4px solid #10b981 !important;">
          <div class="card-body p-4">
            <div class="d-flex align-items-center justify-content-between">
              <div>
                <div class="text-xs font-weight-bold text-gray-400 text-uppercase mb-1" style="letter-spacing: 0.05em;">INVENTORY ITEMS</div>
                <div class="h3 mb-0 font-weight-bold text-gray-800">{{ $product_count }}</div>
              </div>
              <div style="background: rgba(16, 185, 129, 0.1); width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-boxes-stacked" style="color: #10b981; font-size: 1.2rem;"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Low Stock Card -->
      <div class="col-xl-2 col-md-6 mb-4">
        <a href="{{ route('product.low-stock') }}" style="text-decoration: none;">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; border-left: 4px solid #ef4444 !important; transition: transform 0.2s;">
              <div class="card-body p-4">
                <div class="d-flex align-items-center justify-content-between">
                  <div>
                    <div class="text-xs font-weight-bold text-danger text-uppercase mb-1" style="letter-spacing: 0.05em;">LOW STOCK</div>
                    <div class="h3 mb-0 font-weight-bold text-danger">{{ $low_stock_count }}</div>
                  </div>
                  <div style="background: rgba(239, 68, 68, 0.1); width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-triangle-exclamation" style="color: #ef4444; font-size: 1.2rem;"></i>
                  </div>
                </div>
              </div>
            </div>
        </a>
      </div>

      <!-- Orders Card -->
      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; border-left: 4px solid #f59e0b !important;">
          <div class="card-body p-4">
            <div class="d-flex align-items-center justify-content-between">
              <div>
                <div class="text-xs font-weight-bold text-gray-400 text-uppercase mb-1" style="letter-spacing: 0.05em;">CUSTOMER ORDERS</div>
                <div class="h3 mb-0 font-weight-bold text-gray-800">{{ $order_count }}</div>
              </div>
              <div style="background: rgba(245, 158, 11, 0.1); width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-cart-shopping" style="color: #f59e0b; font-size: 1.2rem;"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Inventory Value -->
      <div class="col-xl-2 col-md-6 mb-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; border-left: 4px solid #6366f1 !important;">
          <div class="card-body p-4">
            <div class="d-flex align-items-center justify-content-between">
              <div>
                <div class="text-xs font-weight-bold text-gray-400 text-uppercase mb-1" style="letter-spacing: 0.05em;">STOCK VALUE</div>
                <div class="h3 mb-0 font-weight-bold text-gray-800">Rs. {{ number_format($total_stock_value / 1000, 1) }}k</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    <!-- Stats Row 2: Operationals & Register Balance -->
    <div class="row mb-4">
        <!-- Staff & Suppliers Combined -->
        <div class="col-md-4">
            <div class="row">
                <div class="col-md-12 mb-4">
                     <div class="card border-0 shadow-sm h-100 py-3" style="border-radius: 15px; background: #1e293b;">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-white-50 text-uppercase mb-1">TOTAL EMPLOYEES</div>
                                    <div class="h5 mb-0 font-weight-bold text-white">{{$staff_count}} Staff Members</div>
                                </div>
                                <div class="col-auto">
                                    <div style="background: rgba(255,255,255,0.1); width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-users-gear text-white-50"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 mb-4">
                    <div class="card border-0 shadow-sm h-100 py-3" style="border-radius: 15px; background: #10b981;">
                       <div class="card-body">
                           <div class="row no-gutters align-items-center">
                               <div class="col mr-2">
                                   <div class="text-xs font-weight-bold text-white-50 text-uppercase mb-1">ACTIVE SUPPLIERS</div>
                                   <div class="h5 mb-0 font-weight-bold text-white">{{$supplier_count}} Partners</div>
                               </div>
                               <div class="col-auto">
                                    <div style="background: rgba(255,255,255,0.1); width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-truck-fast text-white-50"></i>
                                    </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
            </div>
        </div>

        <!-- Cash Register Card -->
        <div class="col-md-4 mb-4">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; background: #6366f1; color: #fff;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between mb-3">
                        <div class="text-xs font-weight-bold text-white-50 text-uppercase">CASH REGISTER AMOUNT</div>
                        <i class="fas fa-cash-register text-white-50"></i>
                    </div>
                    <div class="h2 font-weight-bold mb-1">Rs. {{ number_format($register_balance, 2) }}</div>
                    <div class="small mb-3">
                        Status: <span class="badge badge-light text-primary">{{ $active_register ? 'OPEN' : 'CLOSED' }}</span>
                    </div>
                    @if($active_register)
                        <div class="small opacity-75">Opened by: {{ $active_register->staff->name ?? 'N/A' }}</div>
                        <div class="small opacity-75">At: {{ \Carbon\Carbon::parse($active_register->opened_at)->format('h:i A') }}</div>
                    @else
                        <a href="{{route('admin.cash-register')}}" class="btn btn-sm btn-light mt-2" style="border-radius: 8px; color: #6366f1; font-weight: 700;">Start Session</a>
                    @endif
                </div>
            </div>
        </div>

        <!-- Quick Action / System Status -->
        <div class="col-md-4 mb-4">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 15px;">
                <div class="card-body p-4 d-flex flex-column justify-content-center">
                    <div class="d-flex align-items-center mb-2">
                        <div class="mr-3" style="background: #f0fdf4; width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-circle-check text-success"></i>
                        </div>
                        <h6 class="font-weight-bold text-gray-800 mb-0">System Performance</h6>
                    </div>
                    <p class="small text-muted mb-0">All modules are operating within normal parameters.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Row 3: Packaging & Stock -->
    <div class="row mb-4">
        <!-- Packaging Stickers Card -->
        <div class="col-md-6">
            <div class="card border-left-info shadow h-100 py-2" style="border-radius: 15px;">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Packaging Stickers Stock</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ number_format($sticker_count, 2) }} units</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-sticky-note fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Packaging Boxes Card -->
        <div class="col-md-6">
            <div class="card border-left-warning shadow h-100 py-2" style="border-radius: 15px;">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Packaging Boxes Stock</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ number_format($box_count, 2) }} units</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-box-open fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Main Column: Orders & Calendar -->
        <div class="col-xl-8 col-lg-7">
            <!-- Weekly Orders Graph -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-header py-4 bg-transparent border-0 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-gray-800"><i class="fas fa-shopping-cart text-primary mr-2"></i> Weekly Customer Orders</h6>
                    <div class="badge badge-primary badge-pill px-3 py-2">Last 7 Days</div>
                </div>
                <div class="card-body">
                    <div class="chart-bar" style="height: 300px;">
                        <canvas id="ordersChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Task Calendar -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-header py-4 bg-transparent border-0 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-gray-800"><i class="fas fa-calendar-check text-success mr-2"></i> Task Calendar</h6>
                    <a href="{{ route('tasks.calendar') }}" class="btn btn-sm btn-light border" style="border-radius: 10px;">View Full</a>
                </div>
                <div class="card-body">
                    <div id="dashboard-calendar"></div>
                </div>
            </div>
        </div>

        <!-- Side Column: Today's Tasks & New Products -->
        <div class="col-xl-4 col-lg-5">
            <!-- Today's Daily Tasks -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-header py-4 bg-transparent border-0">
                    <h6 class="m-0 font-weight-bold text-gray-800"><i class="fas fa-list-check text-warning mr-2"></i> Today's Daily Tasks</h6>
                </div>
                <div class="card-body p-0">
                    <div class="px-4 pb-4">
                        @forelse($today_tasks as $task)
                            <div class="d-flex align-items-start mb-3 p-3 rounded-lg" style="background: #f8fafc; border-left: 4px solid {{ $task->color ?? '#3b82f6' }};">
                                <div class="flex-grow-1">
                                    <div class="font-weight-bold text-gray-800" style="font-size: 0.9rem;">{{ $task->title }}</div>
                                    <div class="small text-muted mt-1">{{ $task->start_date->format('h:i A') }} - Assigned: {{ $task->assignee->name ?? 'None' }}</div>
                                </div>
                                <span class="badge badge-{{ $task->priority == 'urgent' ? 'danger' : ($task->priority == 'high' ? 'warning' : 'info') }} py-1 px-2" style="font-size: 0.65rem;">{{ strtoupper($task->priority) }}</span>
                            </div>
                        @empty
                            <div class="text-center py-4">
                                <i class="fas fa-tasks fa-3x text-gray-100 mb-2"></i>
                                <p class="text-muted small">No pending tasks for today.</p>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>

            <!-- New Products Widget -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-header py-4 bg-transparent border-0 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-gray-800"><i class="fas fa-plus-circle text-info mr-2"></i> New Arrivals</h6>
                </div>
                <div class="card-body p-0 pb-3">
                    @foreach($new_products as $product)
                        <div class="d-flex align-items-center px-4 py-3 border-bottom" style="border-color: rgba(0,0,0,0.03) !important;">
                            <div class="mr-3" style="width: 45px; height: 45px; border-radius: 10px; background: #f1f5f9; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                @if($product->photo)
                                    <img src="{{ explode(',', $product->photo)[0] }}" style="width: 100%; height: 100%; object-fit: cover;">
                                @else
                                    <i class="fas fa-image text-gray-300"></i>
                                @endif
                            </div>
                            <div class="flex-grow-1 overflow-hidden">
                                <div class="font-weight-bold text-gray-800 text-truncate" style="font-size: 0.85rem;">{{ $product->title }}</div>
                                <div class="text-info font-weight-bold" style="font-size: 0.75rem;">PKR {{ number_format($product->price) }}</div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- User Pie Chart (Moved to side) -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-header py-4 bg-transparent border-0">
                    <h6 class="m-0 font-weight-bold text-gray-800"><i class="fas fa-chart-pie text-gray-500 mr-2"></i> User Distribution</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-2 pb-2" style="height: 200px;">
                      <canvas id="myPieChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Lists Row: Trending & Recent Customers -->
    <div class="row">
        <!-- Trending Products -->
        <div class="col-lg-7 mb-4">
            <div class="card border-0 shadow-sm h-100 overflow-hidden" style="border-radius: 15px;">
                <div class="card-header py-4 d-flex flex-row align-items-center justify-content-between bg-transparent border-0">
                    <h6 class="m-0 font-weight-bold text-gray-800">
                        <i class="fas fa-star text-warning mr-2"></i> Trending Products
                    </h6>
                    <a href="{{route('product.index')}}" class="btn btn-sm btn-light border px-3" style="border-radius: 10px; font-size: 0.75rem; font-weight: 600;">Full Inventory</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0" style="font-size: 0.9rem;">
                            <thead style="background: #f8fafc; color: #64748b; font-weight: 700; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.05em;">
                                <tr>
                                    <th class="border-0 px-4 py-3">PRODUCT</th>
                                    <th class="border-0 text-center py-3">SALES</th>
                                    <th class="border-0 text-right px-4 py-3">STATUS</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($best_sellers as $item)
                                <tr style="border-bottom: 1px solid rgba(0,0,0,0.03);">
                                    <td class="px-4 py-4">
                                        <div class="font-weight-bold text-gray-700">{{ $item->product->title ?? 'N/A' }}</div>
                                    </td>
                                    <td class="text-center py-4">
                                        <div class="progress" style="height: 10px; border-radius: 10px;">
                                            <div class="progress-bar bg-primary" role="progressbar" style="width: {{ min(100, $item->total_qty * 5) }}%" aria-valuenow="{{$item->total_qty}}" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <small class="text-muted mt-1 d-block">{{ $item->total_qty }} Sold</small>
                                    </td>
                                    <td class="text-right px-4 py-4">
                                        @if(($item->product->stock ?? 0) <= 5)
                                            <span class="badge badge-danger px-2 py-1">Low Stock</span>
                                        @else
                                            <span class="badge badge-success px-2 py-1">In Stock</span>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Registered Customers -->
        <div class="col-lg-5 mb-4">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 15px;">
                <div class="card-header py-4 bg-transparent border-0">
                    <h6 class="m-0 font-weight-bold text-gray-800"><i class="fas fa-user-clock text-primary mr-2"></i> Recent Customers</h6>
                </div>
                <div class="card-body p-4 pt-0">
                    @foreach($recent_customers as $customer)
                    <div class="d-flex align-items-center mb-3 p-3 rounded-lg" style="border: 1px solid rgba(0,0,0,0.03); background: #fbfcfd; border-radius: 12px !important;">
                        <div class="mr-3 shadow-sm" style="background: #3b82f6; color: #fff; width: 42px; height: 42px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-weight: 800;">
                            {{ substr($customer->name, 0, 1) }}
                        </div>
                        <div class="flex-grow-1">
                            <div class="font-weight-bold text-gray-700" style="font-size: 0.9rem;">{{ $customer->name }}</div>
                            <div class="text-gray-400 small" style="font-size: 0.7rem;">Registered: {{ $customer->created_at->format('M d, Y') }}</div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    
  </div>

  <!-- Today's Payment Reminders Modal -->
  @if(count($today_reminders) > 0)
  <div class="modal fade" id="todayRemindersModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
            <div class="modal-header bg-dark text-white p-4">
                <div class="d-flex align-items-center">
                    <div style="background: rgba(255,255,255,0.1); width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-right: 15px;">
                        <i class="fas fa-bell fa-lg text-warning animated shake"></i>
                    </div>
                    <div>
                        <h5 class="modal-title font-weight-bold" id="exampleModalLabel text-white">Today's Payment Reminders</h5>
                        <p class="mb-0 small text-white-50">You have {{ count($today_reminders) }} payments due for today, {{ date('M d, Y') }}</p>
                    </div>
                </div>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0" style="font-size: 0.9rem;">
                        <thead class="bg-light">
                            <tr>
                                <th class="px-4 py-3 border-0">TYPE</th>
                                <th class="py-3 border-0">PARTY (CUSTOMER/SUPPLIER)</th>
                                <th class="py-3 border-0">REFERENCE</th>
                                <th class="pr-4 py-3 border-0 text-right">AMOUNT DUE</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($today_reminders as $reminder)
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.03);">
                                <td class="px-4 py-4">
                                    <span class="badge badge-{{ $reminder->type == 'receivable' ? 'success' : 'danger' }} px-3 py-2" style="border-radius: 8px;">
                                        {{ strtoupper($reminder->type == 'receivable' ? 'Receive' : 'Pay') }}
                                    </span>
                                </td>
                                <td>
                                    <div class="font-weight-bold text-gray-800">{{ $reminder->party->name ?? 'N/A' }}</div>
                                    <div class="small text-muted"><i class="fas fa-phone mr-1"></i> {{ $reminder->party->phone ?? 'No Phone' }}</div>
                                </td>
                                <td>
                                    <div class="font-weight-bold text-primary">{{ $reminder->reference_number ?: 'GENERAL' }}</div>
                                    <div class="small text-muted">{{ $reminder->notes ?: 'No extra notes' }}</div>
                                </td>
                                <td class="pr-4 text-right font-weight-bold text-dark h6">
                                    PKR {{ number_format($reminder->amount - $reminder->paid_amount, 2) }}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                
                <div class="p-4 bg-light border-top">
                    <div class="row align-items-center">
                        <div class="col-md-7">
                            <p class="mb-0 small text-muted">A total of <strong>PKR {{ number_format($today_reminders->sum('amount') - $today_reminders->sum('paid_amount'), 2) }}</strong> of business cashflow is active for today.</p>
                        </div>
                        <div class="col-md-5 text-right">
                            <a href="{{ route('payment-reminders.index') }}" class="btn btn-primary shadow-sm" style="border-radius: 10px; font-weight: 600;">
                                Go to Reminders Module <i class="fas fa-arrow-right ml-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  @endif

  <footer class="sticky-footer bg-transparent py-4 mt-2">
    <div class="container my-auto">
      <div class="copyright text-center my-auto text-gray-400 small">
        Copyright © Danyal Autos 2026
      </div>
    </div>
  </footer>

@endsection

@push('styles')
<link href="{{asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.1.9/sweetalert2.min.css">
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
<style>
    .fc-toolbar-title { font-size: 1.1rem !important; font-weight: 700 !important; color: #1e293b; }
    .fc-button-primary { background-color: #3b82f6 !important; border-color: #3b82f6 !important; }
    .fc-daygrid-event { border-radius: 4px; padding: 2px 5px; font-size: 0.75rem; }
    .fc-header-toolbar { margin-bottom: 1.5rem !important; }
    #dashboard-calendar { background: white; padding: 10px; border-radius: 10px; }
</style>
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
<script type="text/javascript">
  // Live Clock Update
  setInterval(() => {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    document.getElementById('live-clock').innerHTML = `<i class="far fa-clock mr-1"></i> ${timeString}`;
  }, 1000);

  $(document).ready(function() {
    if ($('#todayRemindersModal').length > 0) {
        $('#todayRemindersModal').modal('show');
    }

    // Dashboard Calendar
    var calendarEl = document.getElementById('dashboard-calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 450,
        headerToolbar: {
            left: 'prev,next',
            center: 'title',
            right: 'today'
        },
        events: "{{ route('tasks.calendar-events') }}",
        eventClick: function(info) {
            Swal.fire({
                title: info.event.title,
                text: info.event.extendedProps.description || 'No description',
                icon: 'info'
            });
        }
    });
    calendar.render();

    // Chart Defaults
    Chart.defaults.global.defaultFontFamily = 'Outfit, Nunito, -apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#94a3b8';

    // Orders Bar Chart
    var ctxOrders = document.getElementById("ordersChart").getContext('2d');
    var orderAmountsArr = {!! $order_amounts !!};
    new Chart(ctxOrders, {
        type: 'bar',
        data: {
            labels: {!! $order_labels !!},
            datasets: [{
                label: "Orders",
                backgroundColor: "#3b82f6",
                hoverBackgroundColor: "#2563eb",
                borderColor: "#3b82f6",
                data: {!! $order_counts !!},
                barThickness: 25,
                maxBarThickness: 35,
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: { padding: { left: 10, right: 25, top: 25, bottom: 0 } },
            scales: {
                xAxes: [{
                    gridLines: { display: false, drawBorder: false },
                    ticks: { maxTicksLimit: 7 }
                }],
                yAxes: [{
                    ticks: {
                        min: 0,
                        maxTicksLimit: 5,
                        padding: 10,
                        beginAtZero: true,
                        callback: function(value) { if (value % 1 === 0) return value; }
                    },
                    gridLines: {
                        color: "rgba(0, 0, 0, .03)",
                        zeroLineColor: "transparent",
                        drawBorder: false,
                        borderDash: [5, 5]
                    }
                }],
            },
            legend: { display: false },
            tooltips: {
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10,
                callbacks: {
                    label: function(tooltipItem, chart) {
                        var label = chart.datasets[tooltipItem.datasetIndex].label || '';
                        var amount = orderAmountsArr[tooltipItem.index];
                        var formattedAmount = new Intl.NumberFormat('en-PK', { style: 'currency', currency: 'PKR', minimumFractionDigits: 0 }).format(amount);
                        return [
                            'Orders: ' + tooltipItem.yLabel,
                            'Amount: ' + formattedAmount
                        ];
                    }
                }
            }
        }
    });

    // User Pie Chart
    var ctxPie = document.getElementById("myPieChart").getContext('2d');
    var analytics = {!! $users !!};
    analytics.shift(); 
    
    new Chart(ctxPie, {
        type: 'doughnut',
        data: {
          labels: analytics.map(x => x[0]),
          datasets: [{
            data: analytics.map(x => x[1]),
            backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#6366f1'],
            hoverBorderColor: "#fff",
            borderWidth: 5,
          }],
        },
        options: {
          maintainAspectRatio: false,
          tooltips: {
            backgroundColor: "#1e293b",
            xPadding: 15,
            yPadding: 15,
            displayColors: false,
          },
          legend: { display: false },
          cutoutPercentage: 75,
        },
    });
  });
</script>
@endpush
