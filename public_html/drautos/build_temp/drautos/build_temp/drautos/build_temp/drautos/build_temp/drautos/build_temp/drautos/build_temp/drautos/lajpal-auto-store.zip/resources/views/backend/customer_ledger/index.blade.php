@extends('backend.layouts.master')
@section('title','Customer Ledgers')
@section('main-content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Customer Ledgers</h6>
        </div>
        <div class="card-body">
            <form method="GET" class="mb-4">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Search by name, phone or email..." value="{{request()->search}}">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </div>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Customer Type</th>
                            <th>Current Balance</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($customers as $customer)
                            <tr>
                                <td>{{$customer->name}}</td>
                                <td>{{$customer->phone}}</td>
                                <td><span class="badge badge-info text-capitalize">{{$customer->customer_type ?? 'Retail'}}</span></td>
                                <td class="{{$customer->current_balance > 0 ? 'text-danger' : 'text-success'}} font-weight-bold">
                                    Rs. {{number_format($customer->current_balance, 2)}}
                                </td>
                                <td>
                                    <a href="{{route('admin.customer-ledger.show', $customer->id)}}" class="btn btn-primary btn-sm">
                                        <i class="fas fa-eye"></i> View Ledger
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">No customers found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            {{$customers->links()}}
        </div>
    </div>
</div>
@endsection
