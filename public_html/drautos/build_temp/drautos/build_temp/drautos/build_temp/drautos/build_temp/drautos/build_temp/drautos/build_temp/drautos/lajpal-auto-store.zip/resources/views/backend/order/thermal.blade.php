<!DOCTYPE html>
<html>
<head>
    <title>Thermal Receipt - {{ $order->order_number }}</title>
    <style>
        @page {
            margin: 0;
            size: 80mm auto;
        }
        body {
            font-family: 'Courier New', Courier, monospace; /* Classic receipt font often looks more professional for thermal */
            font-size: 12px;
            width: 74mm;
            margin: 0;
            padding: 10px 2mm 20px 6mm; /* Increased left padding (6mm) */
            color: #000;
            line-height: 1.2;
        }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        .divider { border-top: 1px dashed #000; margin: 5px 0; }
        .double-divider { border-top: 2px solid #000; margin: 3px 0; }
        
        .header h2 { 
            margin: 0; 
            font-size: 18px; 
            text-transform: uppercase;
            font-family: Arial, sans-serif;
            font-weight: 900;
        }
        .header p { 
            margin: 2px 0; 
            font-size: 11px;
        }

        .order-meta {
            margin: 8px 0;
            font-size: 11px;
        }
        .order-meta table {
            width: 100%;
            margin: 0;
        }
        .order-meta td {
            padding: 1px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 5px 0;
        }
        th {
            text-align: left;
            font-size: 11px;
            border-bottom: 1px solid #000;
            padding: 3px 0;
            font-family: Arial, sans-serif;
        }
        td {
            padding: 4px 0;
            font-size: 11px;
            vertical-align: top;
        }
        
        .item-row td {
            border-bottom: 0.1mm solid #ccc;
        }
        .item-name {
            display: block;
            font-weight: bold;
            font-family: Arial, sans-serif;
        }

        .totals-section {
            margin-top: 5px;
        }
        .totals-section table td {
            padding: 1px 0;
        }
        .grand-total {
            font-size: 14px;
            font-weight: bold;
            border-top: 1px solid #000;
            border-bottom: 1px solid #000;
            padding: 5px 0 !important;
        }

        .footer {
            margin-top: 15px;
            font-size: 10px;
        }
        .urdu-text {
            font-size: 13px;
            line-height: 1.6;
            margin-bottom: 10px;
            font-weight: bold;
            direction: rtl;
        }

        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="header text-center">
        <h2>DANIYAL AUTOS</h2>
        <p>12-BUTT MARKET BADAMI BAGH LAHORE</p>
        <p>Contact: +923042000274 | 04237727045</p>
    </div>

    <div class="divider"></div>

    <div class="order-meta">
        <table>
            <tr>
                <td width="40%">Receipt #:</td>
                <td class="text-right"><strong>{{ $order->order_number }}</strong></td>
            </tr>
            <tr>
                <td>Date/Time:</td>
                <td class="text-right">{{ $order->created_at->format('d/m/Y h:i A') }}</td>
            </tr>
            <tr>
                <td>Customer:</td>
                <td class="text-right">{{ strtoupper($order->first_name) }}</td>
            </tr>
            @if($order->courier_company)
            <tr>
                <td>Courier:</td>
                <td class="text-right">{{ strtoupper($order->courier_company) }}</td>
            </tr>
            @endif
        </table>
    </div>

    <div class="double-divider"></div>

    <table>
        <thead>
            <tr>
                <th style="width: 50%;">ITEM</th>
                <th class="text-center" style="width: 15%;">QTY</th>
                <th class="text-right" style="width: 35%;">PRICE (DISC.)</th>
            </tr>
        </thead>
        <tbody>
            @foreach($order->cart_info as $cart)
            <tr class="item-row">
                <td>
                    <span class="item-name">{{ $cart->product->title ?? 'N/A' }}</span>
                    <small>@ <del>Rs.{{ number_format($cart->product->price ?? $cart->price, 0) }}</del> Rs. {{ number_format($cart->price, 0) }} (Disc.)</small>
                </td>
                <td class="text-center" style="vertical-align: middle;">
                    {{ $cart->quantity }}
                    @if($cart->product && $cart->product->unit)
                        <br><small>{{ $cart->product->unit }}</small>
                    @endif
                </td>
                <td class="text-right" style="vertical-align: middle;">{{ number_format($cart->amount, 0) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="totals-section">
        <table style="width: 100%;">
            @php
                $total_paid = $order->total_amount;
                if ($order->payment_status == 'partial') {
                    $pending = \App\Models\PaymentReminder::where('reference_number', $order->order_number)->sum('amount');
                    $total_paid = $order->total_amount - $pending;
                } elseif ($order->payment_status == 'unpaid') {
                    $total_paid = 0;
                }
            @endphp
            <tr>
                <td class="font-bold">SUB TOTAL</td>
                <td class="text-right font-bold">Rs. {{ number_format($order->total_amount, 0) }}</td>
            </tr>
            <tr>
                <td>Sub Total</td>
                <td class="text-right">Rs. {{ number_format($order->sub_total, 0) }}</td>
            </tr>
            @php 
                $item_discount = 0;
                foreach($order->cart_info as $ci) {
                    $actual = $ci->product->price ?? $ci->price;
                    if($actual > $ci->price) {
                        $item_discount += ($actual - $ci->price) * $ci->quantity;
                    }
                }
            @endphp
            @if($item_discount > 0)
            <tr>
                <td>Item Discounts</td>
                <td class="text-right">- Rs. {{ number_format($item_discount, 0) }}</td>
            </tr>
            @endif
            @if($order->coupon > 0)
            <tr>
                <td>Total Discount</td>
                <td class="text-right">- Rs. {{ number_format($order->coupon, 0) }}</td>
            </tr>
            @endif
            <tr class="grand-total">
                <td>NET PAYABLE</td>
                <td class="text-right">Rs. {{ number_format($order->total_amount, 0) }}</td>
            </tr>
            <tr>
                <td>Amount Paid</td>
                <td class="text-right">Rs. {{ number_format($total_paid, 0) }}</td>
            </tr>
            <tr>
                <td class="font-bold">REMAINING DUE</td>
                <td class="text-right font-bold">Rs. {{ number_format($order->total_amount - $total_paid, 0) }}</td>
            </tr>
            @if($order->user)
            <tr style="border-top: 1px dotted #000;">
                <td>Total A/C Balance</td>
                <td class="text-right"><strong>Rs. {{ number_format($order->user->current_balance ?? 0, 0) }}</strong></td>
            </tr>
            @endif
        </table>
    </div>

    <div class="double-divider"></div>

    <div class="footer text-center">
        <div class="urdu-text">
            سیلزمین یا سپلائی میں کے ساتھ ذاتي لين دين کي کمپني ذمہ دار نا ہو گي بغیر بل کے کسي بهي سیلزمین کو وصولي نا دیں اور مال لیتے وقت تسلی کر لیں
            <br>
            ہم نے حلال میں ہی برکت رکھی ہے
            <br>
            جو وعدہ پورا کرے، وہی کامیاب ہے
        </div>
        
        <p class="font-bold" style="font-size: 12px; border: 1px solid #000; padding: 2px;">*** THANK YOU ***</p>
        
        <div style="margin-top: 15px; font-size: 8px; opacity: 0.8;">
            This software is designed and developed by (Expert Code Sol) Email: irfanwaince555@gmail.com
        </div>
    </div>

    <script>
        window.onload = function() {
            window.print();
            window.onafterprint = function() {
                window.history.back();
            };
        };
    </script>
</body>
</html>
