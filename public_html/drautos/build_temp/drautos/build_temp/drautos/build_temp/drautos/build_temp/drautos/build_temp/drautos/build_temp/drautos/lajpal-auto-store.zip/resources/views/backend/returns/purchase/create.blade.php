@extends('backend.layouts.master')

@section('title','Create Purchase Return')

@section('main-content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3" style="background: #f8fafc;">
            <h6 class="m-0 font-weight-bold text-primary">Create Purchase Return</h6>
        </div>
        <div class="card-body">
            <form action="{{route('returns.purchase.store')}}" method="POST" id="returnForm">
                @csrf
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="supplier_id" class="font-weight-bold">Supplier <span class="text-danger">*</span></label>
                            <select name="supplier_id" id="supplier_id" class="form-control selectpicker" data-live-search="true" required>
                                <option value="">-- Select Supplier --</option>
                                @foreach($suppliers as $supplier)
                                    <option value="{{$supplier->id}}">{{$supplier->name}} ({{$supplier->company_name}})</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="purchase_order_id" class="font-weight-bold">Purchase Order (Optional)</label>
                            <select name="purchase_order_id" id="purchase_order_id" class="form-control selectpicker" data-live-search="true">
                                <option value="">-- Select Purchase Order --</option>
                                @foreach($purchaseOrders as $po)
                                    <option value="{{$po->id}}">{{$po->purchase_number}} ({{$po->supplier->name}})</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="return_date" class="font-weight-bold">Return Date <span class="text-danger">*</span></label>
                            <input type="date" name="return_date" class="form-control" value="{{date('Y-m-d')}}" required>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="refund_method" class="font-weight-bold">Refund Method <span class="text-danger">*</span></label>
                            <select name="refund_method" class="form-control" required>
                                <option value="cash">Cash</option>
                                <option value="credit_note">Credit Applied to Balance</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="cheque">Cheque</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="refund_reference" class="font-weight-bold">Reference (Optional)</label>
                            <input type="text" name="refund_reference" class="form-control" placeholder="e.g. Transaction ID">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="reason" class="font-weight-bold">Reason</label>
                    <textarea name="reason" class="form-control" rows="2" placeholder="Reason for return..."></textarea>
                </div>

                <hr class="my-4">
                <h6 class="font-weight-bold text-secondary mb-3">Return Items</h6>

                <div class="table-responsive">
                    <table class="table table-bordered" id="items-table">
                        <thead class="bg-light text-dark">
                            <tr>
                                <th style="width: 35%;">Product <span class="text-danger">*</span></th>
                                <th>Quantity <span class="text-danger">*</span></th>
                                <th>Unit Cost (Rs.) <span class="text-danger">*</span></th>
                                <th>Condition <span class="text-danger">*</span></th>
                                <th>Subtotal (Rs.)</th>
                                <th style="width: 50px;"></th>
                            </tr>
                        </thead>
                        <tbody id="items-body">
                            <tr class="item-row">
                                <td>
                                    <select name="items[0][product_id]" class="form-control selectpicker product-select" data-live-search="true" required>
                                        <option value="">-- Select Product --</option>
                                        @foreach($products as $product)
                                            <option value="{{$product->id}}" data-cost="{{$product->purchase_price}}">{{$product->title}}</option>
                                        @endforeach
                                    </select>
                                </td>
                                <td>
                                    <input type="number" name="items[0][quantity]" class="form-control qty-input" min="1" value="1" required>
                                </td>
                                <td>
                                    <input type="number" name="items[0][unit_cost]" class="form-control cost-input" min="0" step="0.01" required>
                                </td>
                                <td>
                                    <select name="items[0][condition]" class="form-control" required>
                                        <option value="expired">Expired</option>
                                        <option value="damaged">Damaged</option>
                                        <option value="wrong_item">Wrong Item</option>
                                        <option value="other">Other</option>
                                    </select>
                                </td>
                                <td>
                                    <input type="number" class="form-control subtotal-input" readonly value="0.00">
                                </td>
                                <td>
                                    <button type="button" class="btn btn-danger btn-sm remove-item rounded-circle"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-right font-weight-bold">Total Return Amount:</td>
                                <td colspan="2"><h5 class="m-0 font-weight-bold text-primary">Rs. <span id="grand-total">0.00</span></h5></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="mb-4">
                    <button type="button" id="add-item" class="btn btn-info btn-sm rounded-pill"><i class="fas fa-plus mr-1"></i> Add Another Product</button>
                </div>

                <div class="form-group mb-0 text-right">
                    <a href="{{route('returns.purchase.index')}}" class="btn btn-light rounded-pill px-4 mr-2 border">Cancel</a>
                    <button class="btn btn-primary rounded-pill px-5 shadow-sm" type="submit">Process Return</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css">
<style>
    .form-control:focus {
        border-color: #4e73df;
        box-shadow: 0 0 0 0.1rem rgba(78, 115, 223, 0.25);
    }
</style>
@endpush

@push('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/js/bootstrap-select.min.js"></script>
<script>
    $(document).ready(function() {
        let itemCount = 1;

        function calculateTotals() {
            let grandTotal = 0;
            $('#items-body tr').each(function() {
                let qty = parseFloat($(this).find('.qty-input').val()) || 0;
                let cost = parseFloat($(this).find('.cost-input').val()) || 0;
                let subtotal = qty * cost;
                $(this).find('.subtotal-input').val(subtotal.toFixed(2));
                grandTotal += subtotal;
            });
            $('#grand-total').text(grandTotal.toFixed(2));
        }

        $('#add-item').click(function() {
            let newRow = $('.item-row:first').clone();
            
            // Update names to include the new index
            newRow.find('select, input').each(function() {
                let name = $(this).attr('name');
                if (name) {
                    $(this).attr('name', name.replace(/items\[\d+\]/, 'items[' + itemCount + ']'));
                }
                $(this).val('');
            });

            newRow.find('.qty-input').val(1);
            newRow.find('.subtotal-input').val('0.00');
            
            // Handle bootstrap-select re-initialization
            newRow.find('.bootstrap-select').replaceWith(function() { 
                return $('select', this); 
            });
            
            $('#items-body').append(newRow);
            $('.selectpicker').selectpicker('render');
            itemCount++;
        });

        $(document).on('click', '.remove-item', function() {
            if ($('#items-body tr').length > 1) {
                $(this).closest('tr').remove();
                calculateTotals();
            }
        });

        $(document).on('change', '.product-select', function() {
            let cost = $(this).find(':selected').data('cost') || 0;
            $(this).closest('tr').find('.cost-input').val(cost);
            calculateTotals();
        });

        $(document).on('input', '.qty-input, .cost-input', function() {
            calculateTotals();
        });

        calculateTotals();
    });
</script>
@endpush
