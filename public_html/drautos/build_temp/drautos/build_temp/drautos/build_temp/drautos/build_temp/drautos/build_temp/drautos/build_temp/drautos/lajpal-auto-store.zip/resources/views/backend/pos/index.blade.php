@extends('backend.layouts.master')
@section('title','POS || Danyal Autos')
@section('main-content')
<div class="container-fluid p-0" style="height: calc(100vh - 100px); overflow: hidden;">
    <div class="row m-0 h-100">
        <!-- Left: Product Selection -->
        <div class="col-lg-8 col-md-7 p-3 h-100 d-flex flex-column" style="background: #f1f5f9;">
            <!-- Search & Filters -->
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body p-2">
                    <div class="input-group input-group-lg">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white border-0"><i class="fas fa-search text-muted"></i></span>
                        </div>
                        <input type="text" id="product-search" class="form-control border-0 shadow-none px-0" placeholder="Scan Barcode or Search Products (Name, SKU)..." autofocus>
                        <div class="input-group-append">
                            <a href="{{route('product.create')}}" class="btn btn-primary d-flex align-items-center px-4" target="_blank">
                                <i class="fas fa-plus mr-2"></i> Add Product
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Categories Bar -->
            <div class="d-flex overflow-auto mb-3 pb-2 no-scrollbar" style="gap: 10px;">
                <button class="btn btn-white shadow-sm px-4 py-2 text-nowrap filter-cat active" data-id="all">All Items</button>
                @foreach($categories as $cat)
                    <button class="btn btn-white shadow-sm px-4 py-2 text-nowrap filter-cat" data-id="{{$cat->id}}">{{$cat->title}}</button>
                @endforeach
            </div>

            <!-- Products Grid -->
            <div id="products-grid" class="row overflow-auto flex-grow-1 pr-2 custom-scrollbar">
                <!-- Products will be loaded here via AJAX -->
                <div class="col-12 text-center py-5">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>
            </div>
        </div>

        <!-- Right: Checkout Sidebar -->
        <div class="col-lg-4 col-md-5 bg-white shadow-sm d-flex flex-column p-0 h-100">
            <!-- Customer Section -->
            <div class="p-3 border-bottom bg-light">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h6 class="m-0 font-weight-bold text-gray-800">Customer</h6>
                    <button class="btn btn-sm btn-outline-info rounded-circle" data-toggle="modal" data-target="#addCustomerModal"><i class="fas fa-plus"></i></button>
                </div>
                <select class="form-control select2 shadow-none" id="customer-select">
                    <option value="1" data-type="walkin">Walk-in Customer</option>
                    @foreach($customers as $customer)
                        <option value="{{$customer->id}}" data-type="{{$customer->customer_type}}">{{$customer->name}} ({{$customer->phone}})</option>
                    @endforeach
                </select>
            </div>

            <!-- Current Order List -->
            <div class="flex-grow-1 overflow-auto p-3 custom-scrollbar" id="cart-items">
                <!-- Cart items here -->
                <div class="text-center py-5 text-muted">
                    <i class="fas fa-shopping-basket fa-3x mb-3 opacity-2"></i>
                    <p>Current order is empty</p>
                </div>
            </div>

            <!-- Summary & Actions -->
            <div class="p-3 bg-dark text-white rounded-top-lg shadow-lg">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-gray-400">Subtotal</span>
                    <span class="font-weight-bold" id="subtotal-val">Rs. 0.00</span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-gray-400">Discount</span>
                    <span class="text-danger" id="discount-val">- Rs. 0.00</span>
                </div>
                <hr style="border-top: 1px solid rgba(255,255,255,0.1);">
                <div class="d-flex justify-content-between mb-4">
                    <span class="h5 m-0">Total</span>
                    <span class="h4 m-0 text-success font-weight-bold" id="total-val">Rs. 0.00</span>
                </div>

                <div class="row no-gutters mb-3">
                    <div class="col-6 pr-1">
                        <button class="btn btn-outline-light btn-block py-3" id="park-order">
                            <i class="fas fa-pause mr-2"></i> Park
                        </button>
                    </div>
                    <div class="col-6 pl-1">
                        <button class="btn btn-outline-danger btn-block py-3" id="clear-cart">
                            <i class="fas fa-trash-alt mr-2"></i> Clear
                        </button>
                    </div>
                </div>

                <button class="btn btn-success btn-lg btn-block py-3 font-weight-bold shadow" data-toggle="modal" data-target="#paymentModal">
                    <i class="fas fa-money-bill-wave mr-2"></i> PROCESS CHECKOUT
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Add Customer Modal -->
<div class="modal fade" id="addCustomerModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="add-customer-form">
                    @csrf
                    <div class="form-group">
                        <label>Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Customer Type</label>
                        <select name="customer_type" class="form-control">
                            <option value="retail">Retail Customer</option>
                            <option value="wholesale">Wholesale Customer</option>
                            <option value="salesman">Salesman</option>
                            <option value="walkin">Walk-in Customer</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="city" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="2"></textarea>
                    </div>
                    <hr>
                    <h6 class="font-weight-bold">Shipping Details</h6>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Shipping City</label>
                            <input type="text" name="shipping_city" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Courier Company</label>
                            <input type="text" name="courier_company" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Courier Number</label>
                        <input type="text" name="courier_number" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Shipping Address</label>
                        <textarea name="shipping_address" class="form-control" rows="2"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="save-customer-btn">Save Customer</button>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title font-weight-bold">Select Payment Method</h5>
                <button type="button" class="close text-white" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div class="modal-body p-4 text-center">
                <h2 class="mb-4 font-weight-bold text-gray-800">Total: <span class="total-payable text-success">Rs. 0.00</span></h2>
                
                <div class="row mb-4">
                    <div class="col-md-3 col-6 mb-3">
                        <div class="payment-card p-3 border rounded shadow-sm cursor-pointer active" data-method="cash">
                            <i class="fas fa-money-bill-1 fa-2x mb-2 text-success"></i>
                            <div class="font-weight-bold">CASH</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="payment-card p-3 border rounded shadow-sm cursor-pointer" data-method="jazzcash">
                            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/87/JazzCash_logo.png/220px-JazzCash_logo.png" height="32" class="mb-2">
                            <div class="font-weight-bold">JAZZCASH</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="payment-card p-3 border rounded shadow-sm cursor-pointer" data-method="easypaisa">
                            <img src="https://seeklogo.com/images/E/easypaisa-logo-7E68E07A5E-seeklogo.com.png" height="32" class="mb-2">
                            <div class="font-weight-bold">EASYPAISA</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="payment-card p-3 border rounded shadow-sm cursor-pointer" data-method="bank">
                            <i class="fas fa-building-columns fa-2x mb-2 text-primary"></i>
                            <div class="font-weight-bold">BANK / CARD</div>
                        </div>
                    </div>
                </div>

                <div class="form-group mb-4">
                    <label class="font-weight-bold">Amount Paid by Customer</label>
                    <input type="number" class="form-control form-control-lg text-center" id="amount-received" placeholder="Enter amount received...">
                </div>

                <!-- Partial Payment Section (Hidden by default) -->
                <div id="partial-payment-info" style="display:none;" class="mb-3">
                    <div class="alert alert-warning">
                        <h6 class="m-0 font-weight-bold">Pending Amount: <span id="pending-val">Rs. 0.00</span></h6>
                    </div>
                    <div class="form-group text-left">
                        <label class="font-weight-bold text-danger">Payment Due Date for Balance</label>
                        <input type="date" class="form-control" id="payment-due-date" value="{{ date('Y-m-d', strtotime('+7 days')) }}">
                    </div>
                </div>

                <div class="p-3 bg-light rounded text-center" id="change-info">
                    <h5 class="m-0">Change Return: <span class="text-danger font-weight-bold" id="change-val">Rs. 0.00</span></h5>
                </div>
            </div>
            <div class="modal-footer border-0 p-4">
                <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success btn-lg px-5 shadow" id="complete-order">SAVE & PRINT INVOICE</button>
            </div>
        </div>
    </div>
</div>

<style>
    .cursor-pointer { cursor: pointer; }
    .payment-card.active { border-color: var(--success) !important; background: rgba(34, 197, 94, 0.05); }
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .custom-scrollbar::-webkit-scrollbar { width: 6px; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    .product-card:hover { transform: translateY(-3px); transition: 0.2s; }
    
    /* Select2 POS Styles */
    .select2-container--default .select2-selection--single {
        height: 45px !important;
        border: 1px solid #d1d3e2 !important;
        border-radius: 5px !important;
        display: flex !important;
        align-items: center !important;
    }
    .select2-container {
        width: 100% !important;
    }
</style>
@endsection

@push('styles')
<link rel="stylesheet" href="{{asset('frontend/js/select2/css/select2.min.css')}}">
<style>
    .select2-dropdown {
        border: 1px solid #d1d3e2 !important;
        box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.15) !important;
    }
</style>
@endpush

@push('scripts')
<script src="{{asset('frontend/js/select2/js/select2.min.js')}}"></script>
<script>
    let cart = [];
    let products = [];

    // Initial Load
    $(document).ready(function() {
        $('#customer-select').select2({
            placeholder: "Select a customer",
            allowClear: false
        });
        fetchProducts('');
    });

    $('#product-search').on('input', function() {
        let query = $(this).val();
        fetchProducts(query);
    });

    $('#customer-select').on('change', function() {
        // Re-render products to show updated prices if we want grid to reflect it
        // Or just relies on addToCart. Let's re-render for better UX.
        renderProducts();
    });

    function fetchProducts(query) {
        $.ajax({
            url: "{{route('pos.search-products')}}",
            data: { query: query },
            success: function(res) {
                products = res;
                renderProducts();
            }
        });
    }

    function getPriceForCustomer(product) {
        let type = $('#customer-select').find(':selected').data('type') || 'retail'; // Default to retail or base price
        
        let price = parseFloat(product.price); // Default Selling Price
        
        if(type == 'wholesale' && product.wholesale_price) price = parseFloat(product.wholesale_price);
        else if(type == 'retail' && product.retail_price) price = parseFloat(product.retail_price);
        else if(type == 'walkin' && product.walkin_price) price = parseFloat(product.walkin_price);
        else if(type == 'salesman' && product.salesman_price) price = parseFloat(product.salesman_price);
        
        return price || 0;
    }

    function renderProducts() {
        let html = '';
        products.forEach(p => {
            let displayPrice = getPriceForCustomer(p);
            let itemTypeBadge = p.item_type == 'bundle' ? '<span class="badge badge-info small mr-1">Bundle</span>' : '';
            
            html += `
                <div class="col-xl-3 col-lg-4 col-md-6 col-6 mb-4">
                    <div class="card product-card h-100 border-0 shadow-sm cursor-pointer" onclick="addToCart(${p.id}, '${p.item_type}')">
                        <img src="${p.photo ? p.photo.split(',')[0] : '{{asset('backend/img/thumbnail-default.jpg')}}'}" class="card-img-top" style="height: 120px; object-fit: cover; border-radius: 12px 12px 0 0;">
                        <div class="card-body p-2">
                            <h6 class="font-weight-bold mb-1 text-truncate">${itemTypeBadge}${p.title}</h6>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-success font-weight-bold small">Rs. ${displayPrice.toFixed(2)}${p.unit ? ' / ' + p.unit : ''}</span>
                                <span class="badge ${p.stock > 0 ? 'badge-light' : 'badge-danger'} small">${p.stock} in stock</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
        $('#products-grid').html(html || '<div class="col-12 text-center py-5">No products found</div>');
    }

    function addToCart(pid, type) {
        // Logic to handle bundles and products with same ID? 
        // IDs are from different tables, so they might collide!
        // PID alone is not enough if we mix products and bundles. 
        // AdminController searchProducts returns results from 2 tables.
        // It's possible Product ID 1 exists and Bundle ID 1 exists.
        // We passed 'type' ('product' or 'bundle') to onclick.
        
        // However, the `products` array contains mixed items. find() will return first match.
        // We really should use a unique ID logic, or filter by type too.
        // Let's rely on type.
        
        let product = products.find(p => p.id == pid && p.item_type == type);
        if(!product) return;
        
        // Use unique ID for cart to avoid collision? 
        // Cart Logic currently uses `id`. 
        // We need to differentiate in Cart too.
        // Or we can prefix ID? 'p-1', 'b-1'.
        
        let cartId = type + '-' + pid; 
        
        let item = cart.find(i => i.unique_id == cartId);
        if(item) {
            item.qty++;
        } else {
            let finalPrice = getPriceForCustomer(product);
            
            cart.push({
                unique_id: cartId, // internal tracker
                id: product.id, // DB id
                type: type,     // 'product' or 'bundle'
                title: product.title,
                original_price: finalPrice,
                price: finalPrice,
                qty: 1,
                unit: product.unit
            });
        }
        renderCart();
    }

    function removeFromCart(index) {
        cart.splice(index, 1);
        renderCart();
    }

    window.updatePrice = function(index, val) {
        let p = parseFloat(val);
        cart[index].price = isNaN(p) ? 0 : p;
        renderCart();
    };

    function updateQty(index, val) {
        cart[index].qty = Math.max(1, parseInt(val));
        renderCart();
    }

    function renderCart() {
        let html = '';
        let subtotal = 0;
        
        if(cart.length == 0) {
            $('#cart-items').html('<div class="text-center py-5 text-muted"><i class="fas fa-shopping-basket fa-3x mb-3 opacity-2"></i><p>Current order is empty</p></div>');
            updateSummary(0);
            return;
        }

        cart.forEach((item, index) => {
            let total = item.price * item.qty;
            subtotal += total;
            html += `
                <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                    <div class="flex-grow-1 pr-2">
                        <h6 class="font-weight-bold m-0" style="font-size: 13px;">${item.title} ${item.unit ? '<small class="text-muted">('+item.unit+')</small>' : ''}</h6>
                        <span class="text-muted" style="font-size: 11px;">MSRP: Rs. ${item.original_price || item.price} ${item.unit ? '/ ' + item.unit : ''}</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="mr-2 text-center">
                            <span class="d-block text-muted" style="font-size: 10px; line-height:1;">Price (Disc.)</span>
                            <input type="number" step="0.01" class="form-control form-control-sm text-center px-1" value="${item.price}" style="width: 65px; height: 28px; font-size: 12px;" onchange="updatePrice(${index}, this.value)">
                        </div>
                        <div class="mr-2 text-center">
                            <span class="d-block text-muted" style="font-size: 10px; line-height:1;">Qty</span>
                            <input type="number" class="form-control form-control-sm text-center px-1" value="${item.qty}" style="width: 50px; height: 28px; font-size: 12px;" onchange="updateQty(${index}, this.value)">
                        </div>
                        <div class="mr-2 text-right">
                            <span class="d-block text-muted" style="font-size: 10px; line-height:1;">Total</span>
                            <span class="font-weight-bold" style="font-size: 13px;">Rs. ${total.toFixed(2)}</span>
                        </div>
                        <button class="btn btn-sm text-danger p-1" onclick="removeFromCart(${index})"><i class="fas fa-times"></i></button>
                    </div>
                </div>
            `;
        });
        $('#cart-items').html(html);
        updateSummary(subtotal);
    }

    function updateSummary(total) {
        $('#subtotal-val').text('Rs. ' + total.toFixed(2));
        $('#total-val').text('Rs. ' + total.toFixed(2));
        $('.total-payable').text('Rs. ' + total.toFixed(2));
    }

    $('.payment-card').on('click', function() {
        $('.payment-card').removeClass('active');
        $(this).addClass('active');
    });

    $('#amount-received').on('input', function() {
        let total = parseFloat($('#total-val').text().replace('Rs. ', ''));
        let received_val = $(this).val();
        let received = received_val === "" ? 0 : parseFloat(received_val);
        if (isNaN(received)) received = 0;
        
        if (received < total) {
            // Partial or No Payment
            $('#change-info').hide();
            $('#partial-payment-info').show();
            $('#pending-val').text('Rs. ' + (total - received).toFixed(2));
        } else {
            // Full Payment or Overpayment
            $('#partial-payment-info').hide();
            $('#change-info').show();
            $('#change-val').text('Rs. ' + (received - total).toFixed(2));
        }
    });

    $('#save-customer-btn').on('click', function() {
        let form = $('#add-customer-form');
        $.ajax({
            url: "{{route('users.store')}}", 
            type: "POST",
            data: form.serialize() + "&role=user&status=active&password=password123", 
            success: function(response) {
                // Add new option with data-type
                let newOption = new Option(response.name + ' (' + response.phone + ')', response.id, true, true);
                $(newOption).data('type', response.customer_type); // Set data attribute
                $('#customer-select').append(newOption).trigger('change');
                $('#addCustomerModal').modal('hide');
                form[0].reset();
                Swal.fire('Success', 'Customer Added', 'success');
            },
            error: function(err) {
               console.log(err);
               let errorMsg = 'Failed to add customer';
               if(err.status === 422) {
                   let errors = err.responseJSON.errors;
                   errorMsg = Object.values(errors).flat().join('\n');
               }
               Swal.fire('Error', errorMsg, 'error');
            }
        });
    });

    $('#complete-order').on('click', function() {
        if(cart.length == 0) {
            Swal.fire('Error', 'Cart is empty!', 'error');
            return;
        }

        let customer_id = $('#customer-select').val();
        let total_amount = parseFloat($('#total-val').text().replace('Rs. ', ''));
        let payment_method = $('.payment-card.active').data('method') || 'cash';
        let amount_received_raw = $('#amount-received').val();
        let amount_received = (amount_received_raw === "" || amount_received_raw === null) ? 0 : parseFloat(amount_received_raw);
        if (isNaN(amount_received)) amount_received = 0;
        let due_date = $('#payment-due-date').val();

        // Prepare data
        let payload = {
            customer_id: customer_id,
            total_amount: total_amount,
            payment_method: payment_method,
            payment_status: (amount_received >= total_amount) ? 'paid' : 'partial',
            amount_paid: amount_received,
            due_date: due_date,
            cart: cart,
            _token: "{{csrf_token()}}"
        };

        $(this).prop('disabled', true).text('Processing...');

        $.ajax({
            url: "{{route('pos.store-order')}}",
            type: "POST",
            data: payload,
            success: function(response) {
                if(response.status == 'success') {
                    if(response.wa_sent) {
                        Swal.fire({
                            title: 'Success!',
                            text: 'Order saved and WhatsApp message sent.',
                            icon: 'success',
                            timer: 2000
                        }).then(() => {
                            window.open(response.invoice_url, '_blank');
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            title: 'Order Saved',
                            text: 'Order created, but WhatsApp message could not be sent. Please check the customer phone number.',
                            icon: 'warning'
                        }).then(() => {
                            window.open(response.invoice_url, '_blank');
                            location.reload();
                        });
                    }
                } else {
                    Swal.fire('Error', response.message, 'error');
                    $('#complete-order').prop('disabled', false).text('SAVE & PRINT INVOICE');
                }
            },
            error: function(err) {
                console.log(err);
                if(err.status === 422) {
                     let errors = err.responseJSON.errors;
                     let msg = '';
                     $.each(errors, function(key, value) {
                         msg += value[0] + '\n';
                     });
                     alert('Validation Error:\n' + msg);
                } else {
                    alert('Something went wrong! Check console.');
                }
                $('#complete-order').prop('disabled', false).text('SAVE & PRINT INVOICE');
            }
        });
    });
</script>
@endpush
