@extends('backend.layouts.master')

@section('main-content')
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Account Payables Report</h1>
        <button class="btn btn-sm btn-primary shadow-sm" onclick="window.print()"><i class="fas fa-print fa-sm text-white-50"></i> Print Report</button>
    </div>

    <!-- Summary -->
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Outstanding Payables</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Rs. {{number_format($totalPayable, 2)}}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-arrow-up fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Pending Payments to Suppliers</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="payablesTable">
                            <thead class="bg-light text-dark">
                                <tr>
                                    <th>Supplier</th>
                                    <th>Ref #</th>
                                    <th>Due Date</th>
                                    <th>Pending Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($payables as $payable)
                                <tr>
                                    <td>{{$payable->party->name ?? 'N/A'}}</td>
                                    <td>{{$payable->reference_number}}</td>
                                    <td class="{{\Carbon\Carbon::parse($payable->due_date)->isPast() ? 'text-danger font-weight-bold' : ''}}">
                                        {{$payable->due_date->format('d M Y')}}
                                    </td>
                                    <td class="font-weight-bold">Rs. {{number_format($payable->amount, 2)}}</td>
                                    <td>
                                        <span class="badge badge-warning">{{strtoupper($payable->status)}}</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="card shadow mb-4 text-center">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Supplier Liability Split</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2" style="height: 300px;">
                        <canvas id="payablePieChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script>
    var ctx = document.getElementById("payablePieChart");
    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: {!! json_encode($bySupplier->map(fn($s) => $s->party->name ?? 'Unknown')) !!},
            datasets: [{
                data: {!! json_encode($bySupplier->pluck('total')) !!},
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796'],
            }],
        },
        options: {
            maintainAspectRatio: false,
            legend: { position: 'bottom' }
        },
    });
</script>
@endpush
